#include "displayMock.h"
#include <iostream>

displayMock::displayMock()
{
}

