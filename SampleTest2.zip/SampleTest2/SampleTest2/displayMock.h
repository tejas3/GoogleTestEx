#ifndef displayMock_H
#define displayMock_H

#include <display.h>
#include <gmock/gmock.h>

class displayMock : public display
{
public:
    displayMock();
    MOCK_METHOD1(printValue, void(int));
};

#endif // displayMock_H
