#ifndef display_H
#define display_H

class display
{
public:
    display();
    virtual void printValue(int val);
};

#endif // display_H
