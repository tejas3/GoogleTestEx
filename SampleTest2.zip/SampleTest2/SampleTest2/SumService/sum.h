#ifndef SUM_H
#define SUM_H

#include <display.h>

class sum
{
public:
    sum(display* disPtr);
    int getValue(int x, int y);
    bool getStatus();

private:
    bool status;
    display* dsPtr;
};

#endif // SUM_H
