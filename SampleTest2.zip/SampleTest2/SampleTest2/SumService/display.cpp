#include "display.h"
#include <iostream>

display::display()
{

}

// 1. return display of values
// 2. if any of the input is 0 then it will retun non zero input value
// 3. if both values are 0 then it should return -1.

void display::printValue(int val)
{
    std::cout <<val << std::endl;
}

