#include "sum.h"

sum::sum(display *disPtr)
    : status(false)
    , dsPtr(disPtr)
{

}

// 1. return sum of values
// 2. if any of the input is 0 then it will retun non zero input value
// 3. if both values are 0 then it should return -1.

int sum::getValue(int x, int y)
{
   int val = 0;
   if(x == 0 && y == 0)
   {
       val = -1;
       dsPtr->printValue(val);
       return val;
   }
   val = x+y;
   dsPtr->printValue(val);
   return val;
}

bool sum::getStatus()
{
   return status;
}

