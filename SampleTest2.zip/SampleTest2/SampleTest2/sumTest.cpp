#include <SumService/sum.h>
#include <displayMock.h>
#include <gtest/gtest.h>


using namespace ::testing;

class SumTests : public ::testing::Test
{
protected:
    SumTests()
        : ds(new displayMock())
        , sumPtr(new sum(ds))
    {

    }
    ~SumTests()
    {
       delete sumPtr;
       delete ds;
    }

    displayMock* ds;
    sum* sumPtr;
};

//Given....When.....Then
TEST_F(SumTests, WhenGetValueCalledThenItShoudReturnCorrectValue)
{
   const int expectedResult = 9;
   EXPECT_CALL(*ds, printValue(9)).Times(1);

   const int value = sumPtr->getValue(4, 5);
   EXPECT_EQ(expectedResult, value);
}

TEST_F(SumTests, GivenZeroValueWhenGetValueCalledThenItShouldReturnZeroValue)
{
    const int expectedResult = -1;
    EXPECT_CALL(*ds, printValue(expectedResult));

    const int value = sumPtr->getValue(0, 0);

    EXPECT_EQ(expectedResult, value);
}
